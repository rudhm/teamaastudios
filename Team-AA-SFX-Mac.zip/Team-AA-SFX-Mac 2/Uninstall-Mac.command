#!/bin/bash
set -euo pipefail
if [[ "$(uname -s)" != "Darwin" ]]; then echo 'This script is for macOS only.'; exit 1; fi
sfx_target="$HOME/Library/Application Support/Adobe/CEP/extensions/com.teamaa.sfx"
sfx_backup_root="$HOME/Library/Application Support/Team AA SFX/extension-backups"
printf 'Close Premiere Pro and After Effects first.\nYour sounds, favorites and tags will be preserved.\n'
read -r -p 'Press Return to remove the panel, or Ctrl+C to cancel. ' sfx_reply
if [[ -d "$sfx_target" ]]; then
 mkdir -p "$sfx_backup_root"
 mv "$sfx_target" "$sfx_backup_root/removed-com.teamaa.sfx-$(date +%Y%m%d-%H%M%S)-$$"
fi
printf 'Panel removed. Restart Adobe apps.\nCEP debug preferences are retained because other unsigned panels may use them.\n'
read -r -p 'Press Return to close. ' sfx_reply
