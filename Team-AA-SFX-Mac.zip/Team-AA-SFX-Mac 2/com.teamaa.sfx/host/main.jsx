var TeamAASFX = {};
TeamAASFX.reply = function(ok, text) { return (ok ? "OK|" : "ERR|") + encodeURIComponent(String(text)); };
TeamAASFX.pick = function() {try {var f = Folder.selectDialog("Choose your SFX folder");return TeamAASFX.reply(true, f ? f.fsName : "");}catch(e){return TeamAASFX.reply(false,e.toString());}};
TeamAASFX.same = function(a,b){try{return new File(a).fsName === new File(b).fsName;}catch(e){return false;}};
TeamAASFX.findPP = function(parent,p){for(var i=0;i<parent.children.numItems;i++){var item=parent.children[i];if(item.type===2){var found=TeamAASFX.findPP(item,p);if(found)return found;}else{try{if(TeamAASFX.same(item.getMediaPath(),p))return item;}catch(e){}}}return null;};
TeamAASFX.run = function(p, place, host) {
 try {
 var file=new File(p);if(!file.exists)throw new Error("Sound file is missing. Reconnect its drive and rescan.");
 if(host === "PPRO") {
  if(!app.project || !app.project.rootItem)throw new Error("Open a Premiere project first.");
  var sequence=app.project.activeSequence,track=null;
  if(place){if(!sequence)throw new Error("Open a sequence first.");for(var t=0;t<sequence.audioTracks.numTracks;t++){var candidate=sequence.audioTracks[t];if(!candidate.isLocked()&&!candidate.isMuted()&&candidate.clips.numItems===0){track=candidate;break;}}if(!track)throw new Error("Create an empty, unlocked, unmuted audio track, then try again.");}
  var item=TeamAASFX.findPP(app.project.rootItem,p);
  if(!item){var bin=null;for(var j=0;j<app.project.rootItem.children.numItems;j++){var child=app.project.rootItem.children[j];if(child.type===2&&child.name==="Team AA SFX"){bin=child;break;}}if(!bin)bin=app.project.rootItem.createBin("Team AA SFX");if(!app.project.importFiles([file.fsName],true,bin,false))throw new Error("Premiere could not import this audio format.");item=TeamAASFX.findPP(app.project.rootItem,p);}
  if(!item)throw new Error("Imported item could not be found.");
  if(place){track.overwriteClip(item,sequence.getPlayerPosition().seconds);if(track.clips.numItems===0)throw new Error("Imported, but placement failed. Check audio track channel compatibility.");}
  return TeamAASFX.reply(true,place?"Added at playhead on an empty audio track.":"Imported into project.");
 }
 if(host === "AEFT") {
  if(!app.project)throw new Error("Open an After Effects project first.");
  var comp=app.project.activeItem;if(place&&!(comp instanceof CompItem))throw new Error("Open a composition first.");
  var footage=null,folder=null;
  for(var k=1;k<=app.project.numItems;k++){var ai=app.project.item(k);if(ai instanceof FootageItem&&ai.file&&TeamAASFX.same(ai.file.fsName,p))footage=ai;if(ai instanceof FolderItem&&ai.name==="Team AA SFX")folder=ai;}
  app.beginUndoGroup("Team AA SFX");
  try{if(!footage){if(!folder)folder=app.project.items.addFolder("Team AA SFX");footage=app.project.importFile(new ImportOptions(file));footage.parentFolder=folder;}if(place){var layer=comp.layers.add(footage);layer.startTime=comp.time;}}
  finally{app.endUndoGroup();}
  return TeamAASFX.reply(true,place?"Added audio layer at playhead.":"Imported into project.");
 }
 throw new Error("This panel supports Premiere Pro and After Effects.");
 }catch(e){return TeamAASFX.reply(false,e.toString());}
};
