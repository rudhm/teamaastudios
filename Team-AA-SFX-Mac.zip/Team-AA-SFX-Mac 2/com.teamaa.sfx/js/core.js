"use strict";
const fs=require('fs'),path=require('path'),crypto=require('crypto'),os=require('os');
const exts=new Set(['.wav','.mp3','.aif','.aiff','.m4a','.aac','.flac','.ogg']);
function suggest(value){
 const s=value.toLowerCase();const rules={whoosh:/who+sh|woo+sh|woosh/,swish:/swish|swoosh/,typing:/typ(e|ing)|keyboard|keystroke/,impact:/impact|hit|slam|punch|boom/,transition:/transition|riser|sweep/,ambience:/ambien|atmos|room.?tone|background/,click:/click|tap|button/,glitch:/glitch|digital|error/,notification:/notif|alert|ding|bell/,cinematic:/cinematic|trailer/};
 return Object.keys(rules).filter(k=>rules[k].test(s));
}
function id(p){return crypto.createHash('sha256').update(p).digest('hex');}
function createStore(dir){
 fs.mkdirSync(dir,{recursive:true});const file=path.join(dir,'library.json');
 function read(){try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch(e){if(e.code==='ENOENT')return {roots:[],meta:{},hover:true,volume:.65};throw new Error('Cannot read saved library: '+e.message);}}
 async function update(fn){const lock=path.join(dir,'write.lock');let locked=false;
 for(let i=0;i<80;i++){try{fs.mkdirSync(lock);locked=true;break;}catch(e){if(e.code!=='EEXIST')throw e;await new Promise(r=>setTimeout(r,50));}}
 if(!locked)throw new Error('Library is busy. Try again; if persistent, close both panels and remove write.lock from the settings folder.');
 try{const data=read();fn(data);const temp=file+'.'+process.pid+'.tmp';fs.writeFileSync(temp,JSON.stringify(data,null,2));fs.renameSync(temp,file);return data;}finally{fs.rmdirSync(lock);}
 }
 return {read,update,dir};
}
async function scan(roots,progress){const files=[],errors=[],seen=new Set();let count=0;
 async function walk(folder){let entries;try{const real=await fs.promises.realpath(folder);if(seen.has(real))return;seen.add(real);entries=await fs.promises.readdir(real,{withFileTypes:true});folder=real;}catch(e){errors.push(folder+': '+e.code);return;}
 for(const entry of entries){if(entry.name.startsWith('.'))continue;const full=path.join(folder,entry.name);if(entry.isDirectory())await walk(full);else if(entry.isFile()&&exts.has(path.extname(entry.name).toLowerCase()))files.push({path:full,name:entry.name,id:id(full),ext:path.extname(entry.name).slice(1).toUpperCase(),auto:suggest(full)});
 if(++count%250===0){if(progress)progress(files.length);await new Promise(r=>setTimeout(r,0));}}
 }
 for(const root of roots)await walk(root);files.sort((a,b)=>a.name.localeCompare(b.name));return {files,errors};
}
module.exports={suggest,id,createStore,scan};
