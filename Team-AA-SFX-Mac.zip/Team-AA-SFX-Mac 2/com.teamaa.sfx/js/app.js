/* Team AA SFX — local-only CEP panel. No network services. */
(function(){
'use strict';
const $=id=>document.getElementById(id),status=msg=>{$('status').textContent=msg;$('status').title=msg;};
window.addEventListener('error',e=>status('Panel error: '+e.message));
window.addEventListener('unhandledrejection',e=>status(e.reason.message||String(e.reason)));
if(!window.__adobe_cep__){status('Open this panel inside Premiere Pro or After Effects.');return;}
let req;try{req=window.cep_node?window.cep_node.require:require;}catch(e){status('Node is unavailable. Reinstall the complete extension folder.');return;}
const fs=req('fs'),path=req('path'),os=req('os'),url=req('url'),cp=req('child_process');
const extRoot=decodeURI(window.__adobe_cep__.getSystemPath('extension')).replace(/^file:\/\//,'');
const core=req(path.join(extRoot,'js','core.js'));
let host;try{host=JSON.parse(window.__adobe_cep__.getHostEnvironment());}catch(e){status('Cannot identify Adobe host.');return;}
$('host').textContent=(host.appId==='PPRO'?'Premiere Pro':'After Effects')+' '+host.appVersion;
$('placement').textContent=host.appId==='PPRO'?'Uses an empty, unlocked, unmuted audio track.':'Creates an audio layer in the active composition.';
const store=core.createStore(path.join(os.homedir(),'Library','Application Support','Team AA SFX'));
let data;try{data=store.read();}catch(e){status(e.message);return;}
let files=[],filtered=[],page=0,tag='',favorites=false,selected=null,scanning=false,hoverTimer=null,playToken=0,peaks=[],audioContext=null,sourcePath='',busy=false,dragging=false,pointerHeld=false;
const pageSize=100,audio=new Audio();audio.preload='metadata';audio.volume=data.volume===undefined?.65:data.volume;
$('volume').value=audio.volume;$('hover').checked=data.hover!==false;
function applyDensity(){document.body.classList.toggle('compact',data.compact!==false);$('density').classList.toggle('active',data.compact===false);$('density').setAttribute('aria-pressed',String(data.compact===false));}
applyDensity();$('density').onclick=async()=>{if(await save(d=>{d.compact=d.compact===false;}))applyDensity();};
$('timeline').title=$('placement').textContent;
const cacheDir=path.join(store.dir,'preview-cache');fs.mkdirSync(cacheDir,{recursive:true});
const conversions=new Map();
function bridge(code){return new Promise((resolve,reject)=>window.__adobe_cep__.evalScript(code,result=>{if(typeof result!=='string'||!/^OK\||^ERR\|/.test(result))return reject(new Error('Adobe scripting connection failed: '+result));let msg;try{msg=decodeURIComponent(result.slice(result.indexOf('|')+1));}catch(e){return reject(e);}result.indexOf('OK|')===0?resolve(msg):reject(new Error(msg));}));}
function literal(s){return JSON.stringify(s).replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029');}
async function save(fn){try{data=await store.update(fn);return true;}catch(e){status('Could not save: '+e.message);return false;}}
function metadata(f){return data.meta[f.id]||{};}
function tagsFor(f){const m=metadata(f);return Array.isArray(m.tags)?m.tags:f.auto;}
function button(label,fn,title){const b=document.createElement('button');b.textContent=label;if(title)b.title=title;b.onclick=fn;return b;}
function rootsView(){const box=$('roots');box.textContent='';data.roots.forEach(root=>{const row=document.createElement('div');row.className='root';const name=document.createElement('span');name.textContent=root;name.title=root;row.appendChild(name);row.appendChild(button('×',async()=>{if(await save(d=>{d.roots=d.roots.filter(p=>p!==root);}))await rescan();},'Remove folder from browser'));box.appendChild(row);});}
// Adobe CEP file payload is set synchronously during dragstart. Never import on dragend:
// native drop/cancel belongs to Adobe, so guessing could create duplicate clips.
function startDrag(ev,f,row){
 if(busy||!ev.dataTransfer||(ev.target.closest&&ev.target.closest('button'))){ev.preventDefault();pointerHeld=false;return;}
 try{
  if(!fs.existsSync(f.path))throw new Error('Sound is missing. Reconnect its drive and rescan.');
  stop();choose(f);dragging=true;pointerHeld=true;
  ev.dataTransfer.clearData();ev.dataTransfer.effectAllowed='copy';
  ev.dataTransfer.setData('com.adobe.cep.dnd.file.0',f.path);
  row.classList.toggle('dragging',true);
  status(host.appId==='PPRO'?'Drop onto an audio track at the desired time.':'Drop onto the composition timeline. If rejected, use Add at playhead.');
 }catch(err){ev.preventDefault();dragging=false;pointerHeld=false;status('Cannot drag: '+err.message);}
}
document.addEventListener('mouseup',()=>{pointerHeld=false;});
function resetResults(){stop();page=0;render();$('list').scrollTop=0;}
function tagView(){const all=new Set(['whoosh','swish','typing','impact','transition','ambience']);files.forEach(f=>tagsFor(f).forEach(t=>all.add(t)));const box=$('tags');box.textContent='';['',...Array.from(all).sort()].forEach(t=>{const b=button(t||'All',()=>{tag=t;resetResults();tagView();});b.setAttribute('aria-pressed',String(tag===t));if(tag===t)b.className='active';box.appendChild(b);});}
function stop(){clearTimeout(hoverTimer);++playToken;audio.pause();audio.currentTime=0;$('play').textContent='▶';}
function choose(f){if(selected&&selected.id===f.id)return;stop();selected=f;sourcePath='';peaks=[];audio.removeAttribute('src');audio.load();$('selectedName').textContent=f.name;$('selectedName').title=f.path;$('time').textContent='0:00 / 0:00';$('tagEditor').hidden=true;['editTags','import','timeline'].forEach(id=>$(id).disabled=false);document.querySelectorAll('.row').forEach(r=>r.classList.toggle('selected',r.dataset.id===f.id));draw();}
function render(){clearTimeout(hoverTimer);const terms=$('search').value.toLowerCase().trim().split(/\s+/).filter(Boolean);filtered=files.filter(f=>{const tags=tagsFor(f);return (!tag||tags.includes(tag))&&(!favorites||metadata(f).favorite)&&terms.every(t=>(f.path+' '+tags.join(' ')).toLowerCase().includes(t));});
const max=Math.max(1,Math.ceil(filtered.length/pageSize));page=Math.max(0,Math.min(page,max-1));$('count').textContent=filtered.length+' / '+files.length+' sounds';$('page').textContent=(page+1)+' / '+max;$('prev').disabled=page===0;$('next').disabled=page===max-1;$('pagination').hidden=max===1;
const list=$('list');list.textContent='';if(!filtered.length){const empty=document.createElement('div');empty.className='empty';empty.textContent=files.length?'No matching sounds.':data.roots.length?'No sounds found. Check the folders or drive.':'Open Folders → Add folder to start.';list.appendChild(empty);return;}
filtered.slice(page*pageSize,(page+1)*pageSize).forEach(f=>{const row=document.createElement('div');row.className='row'+(selected&&selected.id===f.id?' selected':'');row.dataset.id=f.id;row.draggable=true;row.title='Drag to timeline · '+f.path;
const grip=document.createElement('span');grip.className='dragGrip';grip.textContent='⠿';grip.setAttribute('aria-hidden','true');
row.onmousedown=ev=>{if(ev.target.closest&&ev.target.closest('button'))return;pointerHeld=true;stop();};
row.ondragstart=ev=>startDrag(ev,f,row);row.ondragend=()=>{dragging=false;pointerHeld=false;row.classList.toggle('dragging',false);status('Drag ended · if not accepted, use Import or Add at playhead.');};
const play=button('▶',ev=>{ev.stopPropagation();choose(f);playSelected();},'Preview');const info=document.createElement('div');info.className='info';const name=document.createElement('div');name.className='name';name.textContent=f.name;name.title=f.path;const sub=document.createElement('small');sub.textContent=tagsFor(f).join(' · ')||path.basename(path.dirname(f.path));info.append(name,sub);const fmt=document.createElement('span');fmt.className='format';fmt.textContent=f.ext;const star=button(metadata(f).favorite?'★':'☆',async ev=>{ev.stopPropagation();if(await save(d=>{const m=d.meta[f.id]||(d.meta[f.id]={});m.favorite=!m.favorite;}))render();},'Toggle favorite');star.classList.toggle('is-favorite',!!metadata(f).favorite);row.append(grip,play,info,fmt,star);row.onclick=()=>choose(f);
row.onmouseenter=()=>{if(dragging||pointerHeld||!$('hover').checked||busy||!$('folders').hidden||!$('tagEditor').hidden)return;clearTimeout(hoverTimer);hoverTimer=setTimeout(()=>{if(dragging||pointerHeld)return;choose(f);playSelected();},350);};row.onmouseleave=()=>{clearTimeout(hoverTimer);if($('hover').checked&&selected&&selected.id===f.id)stop();};list.appendChild(row);});}
async function rescan(){if(scanning)return;scanning=true;stop();$('refresh').disabled=true;$('addFolder').disabled=true;status('Scanning folders…');try{data=store.read();rootsView();const result=await core.scan(data.roots,n=>status('Scanning… '+n+' sounds'));files=result.files;if(selected&&!files.some(f=>f.id===selected.id)){selected=null;sourcePath='';peaks=[];audio.removeAttribute('src');audio.load();$('selectedName').textContent='Select a sound';['editTags','import','timeline'].forEach(id=>$(id).disabled=true);draw();}tagView();render();status(result.errors.length?'Found '+files.length+' sounds. Some folders were unavailable: '+result.errors.join('; '):'Ready · '+files.length+' sounds indexed');}catch(e){status('Scan failed: '+e.message);}finally{scanning=false;$('refresh').disabled=false;$('addFolder').disabled=false;}}
function convert(p){if(conversions.has(p))return conversions.get(p);const job=(async()=>{const stat=await fs.promises.stat(p);const key=core.id(p+':'+stat.mtimeMs+':'+stat.size);const output=path.join(cacheDir,key+'.wav');if(fs.existsSync(output))return output;const tmp=path.join(cacheDir,key+'.'+Date.now()+'.'+Math.random().toString(16).slice(2)+'.wav');
await new Promise((resolve,reject)=>cp.execFile('/usr/bin/afconvert',['-f','WAVE','-d','LEI16',p,tmp],{timeout:45000,maxBuffer:1024*1024},err=>{if(err){try{fs.unlinkSync(tmp);}catch(e){}reject(new Error('This format cannot be previewed. Try a PCM WAV or MP3 copy.'));}else resolve();}));await fs.promises.rename(tmp,output);return output;})();conversions.set(p,job);job.then(()=>conversions.delete(p),()=>conversions.delete(p));return job;}
async function loadSource(p,token){sourcePath=p;audio.src=url.pathToFileURL(p).href;await new Promise((resolve,reject)=>{let timer;const cleanup=()=>{clearTimeout(timer);audio.removeEventListener('loadedmetadata',ok);audio.removeEventListener('error',bad);};const ok=()=>{cleanup();resolve();};const bad=()=>{cleanup();reject(new Error('Audio decoding failed'));};audio.addEventListener('loadedmetadata',ok);audio.addEventListener('error',bad);timer=setTimeout(()=>{cleanup();reject(new Error('Preview timed out'));},12000);audio.load();});if(token!==playToken)return false;makeWave(p,token);return true;}
async function playSelected(){if(!selected)return;const f=selected,token=++playToken;audio.pause();try{if(!sourcePath||!audio.src||audio.error||audio.readyState<1){let p=f.path;try{if(!await loadSource(p,token))return;}catch(e){if(token!==playToken)return;status('Preparing preview…');p=await convert(f.path);if(token!==playToken)return;if(!await loadSource(p,token))return;}}if(token!==playToken)return;audio.currentTime=0;await audio.play();if(token!==playToken)return;$('play').textContent='Ⅱ';status('Preview · '+f.name);}catch(e){if(token===playToken)status(e.name==='NotAllowedError'?'Click ▶ once to enable audio preview.':e.message);}}
async function makeWave(p,token){try{const stat=await fs.promises.stat(p);if(stat.size>40*1024*1024)return;if(!audioContext)audioContext=new (window.AudioContext||window.webkitAudioContext)();const buf=await fs.promises.readFile(p);const decoded=await audioContext.decodeAudioData(buf.buffer.slice(buf.byteOffset,buf.byteOffset+buf.byteLength));if(token!==playToken)return;const channel=decoded.getChannelData(0),bins=160;peaks=[];for(let i=0;i<bins;i++){let peak=0;const a=Math.floor(i*channel.length/bins),b=Math.floor((i+1)*channel.length/bins);for(let j=a;j<b;j++)peak=Math.max(peak,Math.abs(channel[j]));peaks.push(peak);}draw();}catch(e){/* Playback remains available when waveform decoding is unsupported. */}}
function fmt(n){if(!isFinite(n)||n<0)return '0:00';return Math.floor(n/60)+':'+('0'+Math.floor(n%60)).slice(-2);}
function draw(){const c=$('wave'),ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.clearRect(0,0,w,h);ctx.fillStyle='#45464a';if(!peaks.length){ctx.fillRect(0,h/2,w,1);return;}const progress=audio.duration?audio.currentTime/audio.duration:0;peaks.forEach((v,i)=>{ctx.fillStyle=i/peaks.length<=progress?'#ffdc35':'#626151';const height=Math.max(2,v*(h-8));ctx.fillRect(i*w/peaks.length,(h-height)/2,2.5,height);});}
audio.ontimeupdate=()=>{$('time').textContent=fmt(audio.currentTime)+' / '+fmt(audio.duration);draw();};audio.onloadedmetadata=audio.ontimeupdate;audio.onended=()=>{$('play').textContent='▶';};
$('wave').onclick=e=>{if(isFinite(audio.duration)&&audio.duration>0){audio.currentTime=Math.max(0,Math.min(audio.duration,(e.offsetX/$('wave').clientWidth)*audio.duration));draw();}};
$('play').onclick=()=>{if(!selected)return;if(!audio.paused){audio.pause();$('play').textContent='▶';}else if(audio.src&&audio.readyState>=1&&!audio.error){audio.play().then(()=>{$('play').textContent='Ⅱ';}).catch(e=>status(e.message));}else playSelected();};$('stop').onclick=stop;
$('volume').oninput=()=>{audio.volume=Number($('volume').value);};$('volume').onchange=()=>save(d=>{d.volume=audio.volume;});$('hover').onchange=()=>{stop();save(d=>{d.hover=$('hover').checked;});};
function closeFolders(){$('folders').hidden=true;$('foldersBtn').setAttribute('aria-expanded','false');}
$('closeFolders').onclick=closeFolders;
$('foldersBtn').onclick=()=>{stop();$('folders').hidden=!$('folders').hidden;$('foldersBtn').setAttribute('aria-expanded',String(!$('folders').hidden));};
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeFolders();$('tagEditor').hidden=true;}});
document.addEventListener('mousedown',e=>{if(!$('folders').hidden&&!$('folders').contains(e.target)&&!$('foldersBtn').contains(e.target))closeFolders();});$('addFolder').onclick=async()=>{try{const p=await bridge('TeamAASFX.pick()');if(!p)return;if(await save(d=>{if(!d.roots.includes(p))d.roots.push(p);})){closeFolders();await rescan();}}catch(e){status(e.message);}};
$('refresh').onclick=rescan;$('search').oninput=resetResults;$('favOnly').onclick=()=>{favorites=!favorites;$('favOnly').classList.toggle('active',favorites);$('favOnly').setAttribute('aria-pressed',String(favorites));resetResults();};$('prev').onclick=()=>{page--;render();$('list').scrollTop=0;};$('next').onclick=()=>{page++;render();$('list').scrollTop=0;};
$('editTags').onclick=()=>{if(!selected)return;stop();$('tagInput').value=tagsFor(selected).join(', ');$('tagEditor').hidden=false;$('tagInput').focus();};$('cancelTags').onclick=()=>{$('tagEditor').hidden=true;};$('saveTags').onclick=async()=>{if(!selected)return;const id=selected.id,tags=Array.from(new Set($('tagInput').value.split(',').map(t=>t.trim().toLowerCase()).filter(Boolean)));if(await save(d=>{const m=d.meta[id]||(d.meta[id]={});m.tags=tags;})){$('tagEditor').hidden=true;tagView();render();}};
async function importSound(place){if(!selected||busy)return;busy=true;stop();$('import').disabled=$('timeline').disabled=true;const p=selected.path;status(place?'Adding sound…':'Importing…');try{status(await bridge('TeamAASFX.run('+literal(p)+','+(place?'true':'false')+','+literal(host.appId)+')'));}catch(e){status(e.message);}finally{busy=false;$('import').disabled=$('timeline').disabled=!selected;}}
$('import').onclick=()=>importSound(false);$('timeline').onclick=()=>importSound(true);
window.addEventListener('blur',stop);document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});window.addEventListener('beforeunload',()=>{stop();audio.removeAttribute('src');if(audioContext)audioContext.close();});
window.addEventListener('focus',()=>{pointerHeld=false;if(dragging){dragging=false;document.querySelectorAll('.row').forEach(r=>r.classList.toggle('dragging',false));return;}try{const fresh=store.read(),changed=JSON.stringify(fresh.roots)!==JSON.stringify(data.roots);data=fresh;applyDensity();audio.volume=data.volume===undefined?.65:data.volume;$('volume').value=audio.volume;$('hover').checked=data.hover!==false;if(changed)rescan();else{rootsView();tagView();render();}}catch(e){status(e.message);}});
rescan();
})();
