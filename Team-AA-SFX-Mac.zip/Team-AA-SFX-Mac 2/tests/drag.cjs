// Native host drop cannot be executed without Adobe; exercise the actual drag handlers.
const vm=require('vm'),fs=require('fs'),assert=require('assert'),path=require('path');
class Element{
 constructor(){this.children=[];this.hidden=false;this.scrollTop=0;this.dataset={};this.style={};this.value='';this.tokens=new Set();this.classList={toggle:(k,v)=>v?this.tokens.add(k):this.tokens.delete(k)};}
 set textContent(s){this.text=String(s);this.children=[];}get textContent(){return this.text||'';}
 append(...es){this.children.push(...es);}appendChild(e){this.children.push(e);}setAttribute(k,v){this[k]=v;}removeAttribute(k){delete this[k];}contains(e){return this===e||this.children.includes(e);}focus(){}getContext(){return {clearRect(){},fillRect(){}};}
}
(async()=>{
const html=fs.readFileSync(path.join(__dirname,'../com.teamaa.sfx/index.html'),'utf8'),elements={};for(const m of html.matchAll(/id="([^"]+)"/g))elements[m[1]]=new Element();elements.folders.hidden=true;elements.tagEditor.hidden=true;
const data={roots:['/sounds'],meta:{},hover:true,volume:.6};const sound={id:'one',name:'Swish #1 एक.wav',path:'/Volumes/SFX Packs/Swish #1 एक.wav',ext:'WAV',auto:['swish']};let exists=true,hostCalls=0,pauses=0;const listeners={};
class Audio{constructor(){this.volume=.6;this.currentTime=0;}pause(){pauses++;}load(){}removeAttribute(){}addEventListener(){}removeEventListener(){}}
const store={dir:'/settings',read:()=>data,update:async fn=>{fn(data);return data;}};const core={createStore:()=>store,scan:async()=>({files:[sound],errors:[]})};const modules={fs:{mkdirSync(){},existsSync:()=>exists},path,os:{homedir:()=>'/user'},url:{},child_process:{}};
const window={addEventListener:(k,f)=>listeners[k]=f,__adobe_cep__:{getSystemPath:()=>'/extension',getHostEnvironment:()=>JSON.stringify({appId:'PPRO',appVersion:'26.0'}),evalScript:()=>{hostCalls++;}},cep_node:{require:n=>n.endsWith('core.js')?core:modules[n]}};
const body=new Element();const context={window,document:{body,getElementById:id=>elements[id],createElement:()=>new Element(),querySelectorAll:()=>elements.list.children,addEventListener(){}},Audio,setTimeout,clearTimeout,console};vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(__dirname,'../com.teamaa.sfx/js/app.js'),'utf8'),context);await new Promise(r=>setTimeout(r,10));
assert(body.tokens.has('compact'));await elements.density.onclick();assert(!body.tokens.has('compact'));await elements.density.onclick();assert(body.tokens.has('compact'));
const row=elements.list.children[0];assert.equal(row.draggable,true);let cancelled=false,payload={},clears=0;const transfer={clearData(){payload={};clears++;},setData(k,v){payload[k]=v;}};
const event={target:{closest:()=>null},dataTransfer:transfer,preventDefault:()=>cancelled=true};row.ondragstart(event);
assert.equal(cancelled,false);assert.equal(clears,1);assert.equal(payload['com.adobe.cep.dnd.file.0'],sound.path);assert.equal(Object.keys(payload).length,1);assert.equal(transfer.effectAllowed,'copy');assert(pauses>0);assert.equal(hostCalls,0);assert(row.tokens.has('dragging'));
row.ondragend();assert(!row.tokens.has('dragging'));assert.equal(hostCalls,0,'Cancelled/completed drags must never script a second import');
exists=false;cancelled=false;row.ondragstart(event);assert(cancelled);assert(elements.status.textContent.includes('missing'));assert.equal(hostCalls,0);
exists=true;cancelled=false;row.ondragstart({...event,target:{closest:()=>({})}});assert(cancelled,'Play/favorite buttons must not initiate file drags');
console.log('PASS: native raw file path including spaces/#/Unicode, copy payload, stopped preview, missing-file rejection, drag cleanup/no duplicate import, button exclusion and density persistence.');
})().catch(e=>{console.error(e);process.exit(1);});
