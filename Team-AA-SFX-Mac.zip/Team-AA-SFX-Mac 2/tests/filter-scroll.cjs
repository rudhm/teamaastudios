// Regression: filtering must reset a previously scrolled results container.
const vm=require('vm'),fs=require('fs'),assert=require('assert'),path=require('path');
class Element{
 constructor(){this.children=[];this.hidden=false;this.scrollTop=0;this.dataset={};this.style={};this.value='';this.classList={toggle(){}};this.listeners={};}
 set textContent(s){this.text=String(s);this.children=[];}get textContent(){return this.text||'';}
 append(...els){this.children.push(...els);}appendChild(e){this.children.push(e);}setAttribute(k,v){this[k]=v;}removeAttribute(k){delete this[k];}addEventListener(k,f){this.listeners[k]=f;}contains(e){return this===e||this.children.includes(e);}focus(){}getContext(){return {clearRect(){},fillRect(){}};}
}
(async()=>{
const html=fs.readFileSync(path.join(__dirname,'../com.teamaa.sfx/index.html'),'utf8'),elements={};for(const match of html.matchAll(/id="([^"]+)"/g))elements[match[1]]=new Element();elements.folders.hidden=true;elements.tagEditor.hidden=true;
const data={roots:['/sounds'],meta:{},hover:false,volume:.6};const sounds=Array.from({length:160},(_,i)=>({id:String(i),name:'sound '+i,path:'/sounds/'+i+'.wav',ext:'WAV',auto:i%2?['swish']:['typing']}));
class Audio{constructor(){this.volume=.6;this.currentTime=0;}pause(){}load(){}removeAttribute(){}addEventListener(){}removeEventListener(){}}
const store={dir:'/settings',read:()=>data,update:async fn=>{fn(data);return data;}};
const core={createStore:()=>store,scan:async()=>({files:sounds,errors:[]})};const modules={fs:{mkdirSync(){},existsSync:()=>true},path,os:{homedir:()=>'/user'},url:{},child_process:{}};
const window={addEventListener(){},__adobe_cep__:{getSystemPath:()=>'/extension',getHostEnvironment:()=>JSON.stringify({appId:'AEFT',appVersion:'26.0'})},cep_node:{require:n=>n.endsWith('core.js')?core:modules[n]}};
const context={window,document:{body:new Element(),getElementById:id=>elements[id],createElement:()=>new Element(),querySelectorAll:()=>[],addEventListener(){}},Audio,setTimeout,clearTimeout,console};vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(__dirname,'../com.teamaa.sfx/js/app.js'),'utf8'),context);await new Promise(r=>setTimeout(r,10));
assert.equal(elements.list.children.length,100);elements.list.scrollTop=940;
elements.tags.children.find(b=>b.textContent==='swish').onclick();assert.equal(elements.list.scrollTop,0);assert.equal(elements.list.children.length,80);assert.equal(elements.pagination.hidden,true);
elements.tags.children.find(b=>b.textContent==='All').onclick();elements.list.scrollTop=900;elements.search.value='sound 1';elements.search.oninput();assert.equal(elements.list.scrollTop,0);assert(elements.list.children.length>0);
elements.list.scrollTop=440;elements.favOnly.onclick();assert.equal(elements.list.scrollTop,0);assert.equal(elements.list.children[0].textContent,'No matching sounds.');
elements.foldersBtn.onclick();assert.equal(elements.folders.hidden,false);elements.closeFolders.onclick();assert.equal(elements.folders.hidden,true);
console.log('PASS: tag/search/favorites reset scroll; tag result count; single-page navigation hides; folder overlay opens and closes.');
})().catch(e=>{console.error(e);process.exit(1);});
