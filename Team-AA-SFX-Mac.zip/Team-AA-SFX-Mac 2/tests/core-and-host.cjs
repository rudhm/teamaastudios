const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path'),vm=require('vm');
const core=require('../com.teamaa.sfx/js/core');
(async()=>{
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'aa-sfx-'));
try{
const root=path.join(temp,'Sounds #1');fs.mkdirSync(path.join(root,'typing'),{recursive:true});fs.writeFileSync(path.join(root,'whoosh.wav'),'');fs.writeFileSync(path.join(root,'typing','keys.MP3'),'');fs.writeFileSync(path.join(root,'ignore.txt'),'');fs.symlinkSync(root,path.join(root,'cycle'));
const scan=await core.scan([root,path.join(root,'typing'),path.join(temp,'missing')]);assert.equal(scan.files.length,2);assert.equal(scan.errors.length,1);assert(scan.files.find(f=>f.name==='keys.MP3').auto.includes('typing'));assert(core.suggest('woosh_02').includes('whoosh'));
const store=core.createStore(path.join(temp,'settings'));await Promise.all([store.update(d=>d.roots.push(root)),store.update(d=>{d.meta.x={favorite:true};})]);assert.equal(store.read().roots[0],root);assert.equal(store.read().meta.x.favorite,true);
fs.writeFileSync(path.join(temp,'settings','library.json'),'{broken');assert.throws(()=>store.read(),/Cannot read saved/);
const source=fs.readFileSync(path.join(__dirname,'../com.teamaa.sfx/host/main.jsx'),'utf8');
function File(p){this.fsName=p;this.exists=true;}
const media={type:1,getMediaPath:()=>'/sound.wav'};let placements=0,imports=0;
const occupied={clips:{numItems:1},isLocked:()=>false,isMuted:()=>false,overwriteClip:()=>{throw Error('Must not overwrite occupied audio');}};
const empty={clips:{numItems:0},isLocked:()=>false,isMuted:()=>false,overwriteClip:(m,time)=>{assert.equal(m,media);assert.equal(time,3);placements++;empty.clips.numItems++;}};
const tracks=[occupied,empty];tracks.numTracks=2;
const children=[media];children.numItems=1;
const pp={project:{rootItem:{children},activeSequence:{audioTracks:tracks,getPlayerPosition:()=>({seconds:3})},importFiles:()=>{imports++;return true;}}};
const context={File,app:pp,encodeURIComponent,Error};vm.createContext(context);vm.runInContext(source,context);
assert(context.TeamAASFX.run('/sound.wav',true,'PPRO').startsWith('OK|'));assert.equal(placements,1);assert.equal(imports,0);
assert(decodeURIComponent(context.TeamAASFX.run('/sound.wav',true,'PPRO')).includes('Create an empty'));assert.equal(placements,1);
pp.project.activeSequence=null;assert(decodeURIComponent(context.TeamAASFX.run('/sound.wav',true,'PPRO')).includes('Open a sequence'));
let undo=0,layer={};function CompItem(){this.time=7;this.layers={add:()=>layer};}function FootageItem(){this.file=new File('/sound.wav');}function FolderItem(){}
Object.assign(context,{CompItem,FootageItem,FolderItem,ImportOptions:function(f){this.file=f;}});const footage=new FootageItem();context.app={project:{activeItem:new CompItem(),numItems:1,item:()=>footage},beginUndoGroup:()=>undo++,endUndoGroup:()=>undo--};
assert(context.TeamAASFX.run('/sound.wav',true,'AEFT').startsWith('OK|'));assert.equal(layer.startTime,7);assert.equal(undo,0);
context.app.project.activeItem.layers.add=()=>{throw Error('Simulated placement failure');};assert(context.TeamAASFX.run('/sound.wav',true,'AEFT').startsWith('ERR|'));assert.equal(undo,0);
console.log('PASS: nested folders, overlap deduplication, missing folders, symlink loop avoidance, tags, concurrent persistence, corrupt settings protection, Premiere no-overwrite/reuse/no-sequence handling, AE playhead and undo cleanup.');
}finally{fs.rmSync(temp,{recursive:true,force:true});}
})().catch(e=>{console.error(e);process.exit(1);});
